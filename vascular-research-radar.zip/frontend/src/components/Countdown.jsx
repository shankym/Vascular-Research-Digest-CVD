import { useEffect, useState } from "react";
import { Clock } from "lucide-react";

export function Countdown({ nextRunTime, lastRunTime, running }) {
  const [left, setLeft] = useState("");
  useEffect(() => {
    const tick = () => {
      if (!nextRunTime) return setLeft("");
      const now = new Date();
      const next = new Date(now);
      next.setUTCMinutes(0, 0, 0);
      next.setUTCHours(next.getUTCHours() + 1);
      const diff = next.getTime() - now.getTime();
      setLeft(`${String(Math.floor(diff / 60000)).padStart(2, "0")}:${String(Math.floor((diff % 60000) / 1000)).padStart(2, "0")}`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [nextRunTime]);

  const last = lastRunTime ? new Date(lastRunTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "Not yet";
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-[hsl(var(--ink-soft))]" data-testid="countdown">
      <span className="flex items-center gap-1.5">
        <Clock className="w-4 h-4" />
        {running ? "Searching now…" : nextRunTime ? (
          <>Next search in <b className="font-mono text-[hsl(var(--ink))]" data-testid="countdown-time">{left}</b></>
        ) : "Hourly search is paused"}
      </span>
      <span>Last search <b className="font-mono font-medium text-[hsl(var(--ink))]">{last}</b></span>
    </div>
  );
}
