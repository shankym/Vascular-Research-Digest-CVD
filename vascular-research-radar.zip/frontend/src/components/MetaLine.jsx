import { Fragment } from "react";
import { formatDate, citationsLabel } from "@/lib/format";

export function MetaLine({ paper, showCategory = true, testId }) {
  const items = [
    showCategory && { t: paper.category },
    { t: paper.journal, strong: true },
    { t: paper.article_type },
    { t: formatDate(paper.publication_date) },
    { t: citationsLabel(paper) },
  ].filter((x) => x && x.t);
  return (
    <p className="min-w-0 break-words text-[0.85rem] leading-relaxed text-[hsl(var(--ink-faint))]" data-testid={testId}>
      {items.map((x, i) => (
        <Fragment key={i}>
          {i > 0 && <span aria-hidden> · </span>}
          <span className={x.strong ? "font-semibold text-[hsl(var(--ink-soft))]" : "whitespace-nowrap"}>{x.t}</span>
        </Fragment>
      ))}
    </p>
  );
}
