import { Search, RotateCcw, Bookmark, CheckCircle2 } from "lucide-react";

const selectCls = "w-full py-2.5 px-3 rounded-xl bg-[hsl(var(--paper))] border text-[0.95rem] focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent)/0.35)]";

function Select({ label, value, onChange, options, testId }) {
  return (
    <label className="block">
      <span className="eyebrow block mb-1">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} className={selectCls} data-testid={testId}>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </label>
  );
}

function Toggle({ on, onClick, icon: Icon, label, testId }) {
  return (
    <button onClick={onClick} aria-pressed={on} data-testid={testId}
      className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-full border text-sm font-medium transition-colors ${on ? "bg-[hsl(var(--ink))] text-[hsl(var(--surface))]" : "bg-[hsl(var(--surface))] hover:bg-[hsl(var(--secondary))]"}`}>
      <Icon className="w-4 h-4" /> {label}
    </button>
  );
}

export function LibraryFilters({ f, set, reset, options }) {
  const all = (label, list) => [["All", label], ...list.map((x) => [x, x])];
  return (
    <div className="surface p-4 sm:p-5 space-y-4" data-testid="library-filters">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-[hsl(var(--ink-faint))]" />
          <input value={f.search} onChange={(e) => set("search", e.target.value)} placeholder="Search title, author, DOI or abstract"
            data-testid="library-search-input"
            className="w-full pl-11 pr-4 py-3 rounded-xl bg-[hsl(var(--paper))] border text-base focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent)/0.35)]" />
        </div>
        <div className="flex gap-2">
          <Toggle on={f.savedOnly} onClick={() => set("savedOnly", !f.savedOnly)} icon={Bookmark} label="Saved" testId="filter-saved-only" />
          <Toggle on={f.readOnly} onClick={() => set("readOnly", !f.readOnly)} icon={CheckCircle2} label="Read" testId="filter-read-only" />
          <button onClick={reset} title="Reset filters" data-testid="filter-reset" className="p-2.5 rounded-full border bg-[hsl(var(--surface))] hover:bg-[hsl(var(--secondary))]"><RotateCcw className="w-4 h-4" /></button>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <Select label="Topic" value={f.category} onChange={(v) => set("category", v)} options={all("All topics", options.categories)} testId="filter-category" />
        <Select label="Journal" value={f.journal} onChange={(v) => set("journal", v)} options={all("All journals", options.journals)} testId="filter-journal" />
        <Select label="Article type" value={f.type} onChange={(v) => set("type", v)} options={all("All types", options.types)} testId="filter-type" />
        <Select label="Year" value={f.year} onChange={(v) => set("year", v)} options={all("All years", options.years)} testId="filter-year" />
        <Select label="Sort" value={f.sort} onChange={(v) => set("sort", v)} testId="filter-sort" options={[
          ["added", "Newest added"], ["published", "Newest published"], ["oldest", "Oldest published"], ["citations", "Most cited"], ["title", "Title A–Z"],
        ]} />
      </div>
    </div>
  );
}
