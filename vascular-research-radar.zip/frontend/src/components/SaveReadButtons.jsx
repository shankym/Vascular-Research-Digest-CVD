import { Bookmark, CheckCircle2 } from "lucide-react";
import { useHistory } from "@/lib/history";

export function SaveReadButtons({ id, withLabels = false }) {
  const h = useHistory();
  const s = h.get(id);
  const base = "flex items-center gap-1.5 rounded-full border transition-colors duration-200 active:scale-[0.97] transition-transform";
  const size = withLabels ? "px-3.5 py-2 text-sm font-medium" : "p-2.5";
  return (
    <div className="flex items-center gap-2 no-print">
      <button
        onClick={() => h.toggleSave(id)}
        data-testid={`save-btn-${id}`}
        aria-pressed={!!s.saved}
        title={s.saved ? "Remove from saved" : "Save"}
        className={`${base} ${size} ${s.saved ? "bg-[hsl(var(--accent-soft))] border-[hsl(var(--accent)/0.4)] text-[hsl(var(--accent))]" : "bg-[hsl(var(--surface))] hover:bg-[hsl(var(--secondary))]"}`}
      >
        <Bookmark className={`w-4 h-4 ${s.saved ? "fill-current" : ""}`} />
        {withLabels && <span>{s.saved ? "Saved" : "Save"}</span>}
      </button>
      <button
        onClick={() => h.toggleRead(id)}
        data-testid={`read-btn-${id}`}
        aria-pressed={!!s.read}
        title={s.read ? "Mark unread" : "Mark read"}
        className={`${base} ${size} ${s.read ? "bg-[hsl(var(--good)/0.12)] border-[hsl(var(--good)/0.4)] text-[hsl(var(--good))]" : "bg-[hsl(var(--surface))] hover:bg-[hsl(var(--secondary))]"}`}
      >
        <CheckCircle2 className="w-4 h-4" />
        {withLabels && <span>{s.read ? "Read" : "Mark read"}</span>}
      </button>
    </div>
  );
}
