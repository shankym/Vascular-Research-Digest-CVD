import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { pubYear } from "@/lib/format";

function buildCitations(p) {
  const year = pubYear(p.publication_date) || "n.d.";
  const authors = p.authors?.length ? p.authors.join(", ") + ((p.authors_total || 0) > p.authors.length ? ", et al." : "") : "";
  const doi = p.DOI ? `https://doi.org/${p.DOI}` : p.PMID ? `PMID: ${p.PMID}` : "";
  const last = (p.authors?.[0] || "anon").split(" ").pop().toLowerCase().replace(/[^a-z]/g, "");
  return [
    { key: "apa", label: "APA 7th", text: `${authors}${authors ? " " : ""}(${year}). ${p.title}. ${p.journal}. ${doi}`.trim() },
    { key: "vancouver", label: "Vancouver", text: `${authors}${authors && !authors.endsWith(".") ? ". " : authors ? " " : ""}${p.title}. ${p.journal}. ${year}.${p.DOI ? ` doi:${p.DOI}.` : ""}${p.PMID ? ` PMID: ${p.PMID}.` : ""}` },
    {
      key: "bibtex",
      label: "BibTeX",
      text: `@article{${last}${year},\n  title = {${p.title}},\n  author = {${(p.authors || []).join(" and ")}},\n  journal = {${p.journal}},\n  year = {${year}}${p.DOI ? `,\n  doi = {${p.DOI}}` : ""}\n}`,
    },
  ];
}

export function CitationModal({ paper, open, onOpenChange }) {
  const [copied, setCopied] = useState("");
  const copy = async (c) => {
    try {
      await navigator.clipboard.writeText(c.text);
      setCopied(c.key);
      setTimeout(() => setCopied(""), 2000);
    } catch {
      toast.error("Couldn't copy. Select the text and copy it manually.");
    }
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-[hsl(var(--surface))]" data-testid="citation-modal">
        <DialogHeader>
          <DialogTitle className="font-read text-xl">Cite this paper</DialogTitle>
          <DialogDescription className="line-clamp-2">{paper.title}</DialogDescription>
        </DialogHeader>
        <div className="space-y-5">
          {buildCitations(paper).map((c) => (
            <div key={c.key}>
              <div className="flex items-center justify-between mb-2">
                <span className="eyebrow">{c.label}</span>
                <button onClick={() => copy(c)} className="flex items-center gap-1.5 text-sm font-semibold text-[hsl(var(--accent))]" data-testid={`copy-citation-${c.key}`}>
                  {copied === c.key ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied === c.key ? "Copied" : "Copy"}
                </button>
              </div>
              <pre className="whitespace-pre-wrap break-words p-3.5 rounded-lg bg-[hsl(var(--secondary))] text-sm font-mono leading-relaxed" data-testid={`citation-text-${c.key}`}>{c.text}</pre>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
