import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { MetaLine } from "@/components/MetaLine";
import { SaveReadButtons } from "@/components/SaveReadButtons";
import { authorsLine, abstractText } from "@/lib/format";

export function PaperCard({ paper, index = 0 }) {
  const preview = paper.conclusion || abstractText(paper);
  return (
    <article
      className="surface p-5 sm:p-6 flex flex-col gap-3 rise hover:border-[hsl(var(--ink-faint)/0.6)] transition-colors"
      style={{ animationDelay: `${Math.min(index, 8) * 50}ms` }}
      data-testid={`paper-card-${paper.paper_id}`}
    >
      <div className="flex items-start justify-between gap-3">
        <MetaLine paper={paper} />
        <SaveReadButtons id={paper.paper_id} />
      </div>
      <Link to={`/paper/${paper.paper_id}`} className="group" data-testid={`paper-card-title-${paper.paper_id}`}>
        <h3 className="font-read text-[1.2rem] sm:text-[1.3rem] font-semibold leading-snug group-hover:text-[hsl(var(--accent))] transition-colors">
          {paper.title}
        </h3>
      </Link>
      <p className="text-[0.92rem] text-[hsl(var(--ink-soft))] line-clamp-1">{authorsLine(paper, 4)}</p>
      {preview ? (
        <p className="font-read text-[1.02rem] leading-relaxed text-[hsl(var(--ink-soft))] line-clamp-3">
          {paper.conclusion && <span className="eyebrow mr-2 !text-[hsl(var(--highlight-ink))]">Conclusion</span>}
          {preview}
        </p>
      ) : (
        <p className="text-[0.95rem] italic text-[hsl(var(--ink-faint))]">Abstract not available</p>
      )}
      <Link
        to={`/paper/${paper.paper_id}`}
        className="mt-auto self-start flex items-center gap-1.5 text-[0.95rem] font-semibold text-[hsl(var(--accent))] hover:gap-2.5 transition-[gap]"
        data-testid={`paper-card-open-${paper.paper_id}`}
      >
        Read paper <ArrowRight className="w-4 h-4" />
      </Link>
    </article>
  );
}
