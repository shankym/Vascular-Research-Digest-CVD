import { NavLink, Link } from "react-router-dom";
import { Moon, Sun, RefreshCw } from "lucide-react";
import { useHistory } from "@/lib/history";

const TABS = [
  { to: "/", label: "Dashboard", id: "dashboard" },
  { to: "/today", label: "Today", id: "today" },
  { to: "/library", label: "Library", id: "library" },
  { to: "/saved", label: "Saved", id: "saved" },
  { to: "/settings", label: "Settings", id: "settings" },
];

const tabClass = ({ isActive }) =>
  `px-3.5 py-2 rounded-full text-[0.95rem] whitespace-nowrap transition-colors duration-200 ${
    isActive ? "bg-[hsl(var(--ink))] text-[hsl(var(--surface))] font-semibold" : "text-[hsl(var(--ink-soft))] hover:bg-[hsl(var(--secondary))]"
  }`;

function Tabs({ savedCount, prefix }) {
  return TABS.map((t) => (
    <NavLink key={t.id} to={t.to} end={t.to === "/"} className={tabClass} data-testid={`${prefix}-tab-${t.id}`}>
      {t.label}
      {t.id === "saved" && savedCount > 0 && <span className="ml-1.5 font-mono text-xs opacity-80">{savedCount}</span>}
    </NavLink>
  ));
}

export function TopNav({ dark, onToggleDark, onRunNow, running }) {
  const { all } = useHistory();
  const savedCount = Object.values(all).filter((h) => h.saved).length;
  return (
    <header className="no-print sticky top-0 z-40 bg-[hsl(var(--paper)/0.85)] backdrop-blur-xl border-b">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 px-4 sm:px-8 py-3.5">
        <Link to="/" className="flex items-center gap-2.5 shrink-0" data-testid="nav-wordmark">
          <span className="w-2.5 h-2.5 rounded-full bg-[hsl(var(--accent))]" aria-hidden />
          <span className="font-read text-lg sm:text-xl font-semibold tracking-tight">Vascular Research Radar</span>
        </Link>
        <nav className="hidden lg:flex items-center gap-1">
          <Tabs savedCount={savedCount} prefix="desktop" />
        </nav>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onToggleDark}
            aria-label="Toggle dark mode"
            data-testid="dark-mode-toggle"
            className="p-2.5 rounded-full hover:bg-[hsl(var(--secondary))] transition-colors"
          >
            {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          <button
            onClick={onRunNow}
            disabled={running}
            data-testid="nav-run-now-button"
            className="flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-full bg-[hsl(var(--accent))] text-white text-sm font-semibold hover:opacity-90 active:scale-[0.98] transition-[opacity,transform] disabled:opacity-60 dark:text-[hsl(var(--paper))]"
          >
            <RefreshCw className={`w-4 h-4 ${running ? "animate-spin" : ""}`} />
            <span className="hidden sm:inline">{running ? "Searching…" : "Run now"}</span>
          </button>
        </div>
      </div>
      <nav className="lg:hidden flex items-center gap-1.5 px-4 pb-3 overflow-x-auto no-scrollbar">
        <Tabs savedCount={savedCount} prefix="mobile" />
      </nav>
    </header>
  );
}
