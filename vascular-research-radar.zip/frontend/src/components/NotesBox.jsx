import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useHistory } from "@/lib/history";

export function NotesBox({ id, compact = false }) {
  const h = useHistory();
  const saved = h.get(id).notes || "";
  const [text, setText] = useState(saved);
  useEffect(() => setText(saved), [id, saved]);
  const dirty = text !== saved;
  return (
    <div className={compact ? "" : "surface p-5 sm:p-8"} data-testid={`notes-box-${id}`}>
      {!compact && <h2 className="font-read text-2xl font-semibold mb-1">Your notes</h2>}
      <p className="text-sm text-[hsl(var(--ink-faint))] mb-3">Kept only on this device.</p>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={compact ? 3 : 5}
        placeholder="Write what matters to you about this paper…"
        data-testid={`notes-textarea-${id}`}
        className="w-full p-4 rounded-xl bg-[hsl(var(--paper))] border text-base font-read leading-relaxed focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent)/0.4)]"
      />
      <div className="flex justify-end mt-3">
        <button
          disabled={!dirty}
          onClick={() => { h.setNotes(id, text); toast.success("Notes saved on this device"); }}
          data-testid={`notes-save-btn-${id}`}
          className="px-5 py-2.5 rounded-full bg-[hsl(var(--ink))] text-[hsl(var(--surface))] font-semibold disabled:opacity-40 transition-opacity"
        >
          Save notes
        </button>
      </div>
    </div>
  );
}
