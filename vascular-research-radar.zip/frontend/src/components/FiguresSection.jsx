import { useState } from "react";
import { ExternalLink, ImageOff } from "lucide-react";
import { fullPaperUrl } from "@/lib/format";

function Figure({ fig }) {
  const [open, setOpen] = useState(false);
  const [broken, setBroken] = useState(false);
  return (
    <figure className="surface overflow-hidden" data-testid={`figure-${fig.id}`}>
      <a href={fig.article_url} target="_blank" rel="noopener noreferrer" className="block bg-white">
        {broken ? (
          <div className="h-48 flex items-center justify-center gap-2 text-[hsl(var(--ink-faint))]"><ImageOff className="w-5 h-5" /> Open in full paper</div>
        ) : (
          <img src={fig.image_url} alt={fig.label} loading="lazy" onError={() => setBroken(true)} className="w-full max-h-[520px] object-contain" />
        )}
      </a>
      <figcaption className="p-4 sm:p-5 border-t">
        <div className="font-semibold mb-1">{fig.label}</div>
        {fig.caption && (
          <>
            <p className={`text-[0.95rem] leading-relaxed text-[hsl(var(--ink-soft))] ${open ? "" : "line-clamp-3"}`}>{fig.caption}</p>
            {fig.caption.length > 220 && (
              <button onClick={() => setOpen(!open)} className="mt-1 text-sm font-semibold text-[hsl(var(--accent))]" data-testid={`figure-caption-toggle-${fig.id}`}>
                {open ? "Show less" : "Show full caption"}
              </button>
            )}
          </>
        )}
        <p className="mt-2 text-xs text-[hsl(var(--ink-faint))]">Source: PubMed Central open-access record. Copyright remains with the publisher/authors.</p>
      </figcaption>
    </figure>
  );
}

export function FiguresSection({ paper }) {
  const url = fullPaperUrl(paper);
  return (
    <section className="space-y-4" data-testid="figures-section">
      <h2 className="font-read text-2xl font-semibold">Figures</h2>
      {paper.figures?.length ? (
        <div className="grid gap-5">{paper.figures.map((f) => <Figure key={f.id} fig={f} />)}</div>
      ) : (
        <div className="surface p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3" data-testid="figures-unavailable">
          <p className="text-[hsl(var(--ink-soft))]">Figures can't be shown here for this paper.</p>
          {url && (
            <a href={url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 font-semibold text-[hsl(var(--accent))]" data-testid="view-figures-full-paper-link">
              View figures in full paper <ExternalLink className="w-4 h-4" />
            </a>
          )}
        </div>
      )}
    </section>
  );
}
