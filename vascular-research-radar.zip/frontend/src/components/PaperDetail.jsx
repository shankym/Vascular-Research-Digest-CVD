import { useState } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft, ExternalLink, Printer, Quote } from "lucide-react";
import { SaveReadButtons } from "@/components/SaveReadButtons";
import { CitationModal } from "@/components/CitationModal";
import { AbstractSection } from "@/components/AbstractSection";
import { FiguresSection } from "@/components/FiguresSection";
import { NotesBox } from "@/components/NotesBox";
import { authorsLine, formatDate, sourceLinks, citationsLabel } from "@/lib/format";

function Detail({ label, children, testId, wide }) {
  return (
    <div className={wide ? "col-span-2 md:col-span-1" : ""}>
      <dt className="eyebrow mb-0.5">{label}</dt>
      <dd className="text-[0.98rem] break-words" data-testid={testId}>{children}</dd>
    </div>
  );
}

function ActionBar({ paper, onCite }) {
  const btn = "flex items-center gap-1.5 px-3.5 py-2 rounded-full border bg-[hsl(var(--surface))] text-sm font-medium hover:bg-[hsl(var(--secondary))] transition-colors";
  return (
    <div className="no-print flex flex-wrap items-center gap-2">
      <SaveReadButtons id={paper.paper_id} withLabels />
      <button onClick={onCite} className={btn} data-testid="cite-button"><Quote className="w-4 h-4" /> Cite</button>
      <button onClick={() => window.print()} className={btn} data-testid="print-button"><Printer className="w-4 h-4" /> Print</button>
    </div>
  );
}

export default function PaperDetail({ paper }) {
  const [cite, setCite] = useState(false);
  const links = sourceLinks(paper);
  return (
    <article className="max-w-4xl mx-auto px-4 sm:px-8 py-6 sm:py-10 space-y-8" data-testid="paper-detail">
      <Link to="/library" className="no-print inline-flex items-center gap-1 text-[0.95rem] text-[hsl(var(--ink-soft))] hover:text-[hsl(var(--ink))]" data-testid="back-to-library">
        <ChevronLeft className="w-4 h-4" /> Library
      </Link>

      <header className="space-y-5 rise">
        <div className="eyebrow !text-[hsl(var(--accent))]">{paper.category}</div>
        <h1 className="font-read text-[1.85rem] sm:text-4xl lg:text-5xl font-semibold leading-[1.15] tracking-tight" data-testid="paper-title">{paper.title}</h1>
        <p className="text-base sm:text-lg text-[hsl(var(--ink-soft))]" data-testid="paper-authors">{authorsLine(paper)}</p>
        <ActionBar paper={paper} onCite={() => setCite(true)} />
      </header>

      <dl className="surface p-5 sm:p-6 grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-4">
        <Detail label="Journal" testId="detail-journal">{paper.journal}</Detail>
        <Detail label="Published" testId="detail-date">{formatDate(paper.publication_date)}</Detail>
        <Detail label="Article type" testId="detail-type">{paper.article_type}</Detail>
        <Detail label="Citations" testId="detail-citations">{citationsLabel(paper) || "Not available"}</Detail>
        <Detail label="Full text" testId="detail-fulltext">{paper.PMCID ? "Free in PubMed Central" : "Via publisher"}</Detail>
        <Detail label="Identifiers" testId="detail-ids" wide>
          <span className="font-mono text-sm">{[paper.PMID && `PMID ${paper.PMID}`, paper.DOI].filter(Boolean).join(" · ") || "Not listed"}</span>
        </Detail>
      </dl>

      {links.length > 0 && (
        <div className="no-print flex flex-wrap gap-2" data-testid="source-links">
          {links.map((l) => (
            <a key={l.key} href={l.href} target="_blank" rel="noopener noreferrer" data-testid={`source-link-${l.key}`}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full border border-[hsl(var(--accent)/0.35)] text-[hsl(var(--accent))] font-semibold text-[0.95rem] hover:bg-[hsl(var(--accent-soft))] transition-colors">
              {l.label} <ExternalLink className="w-4 h-4" />
            </a>
          ))}
        </div>
      )}

      <AbstractSection paper={paper} />
      <FiguresSection paper={paper} />
      <div className="no-print"><NotesBox id={paper.paper_id} /></div>
      <CitationModal paper={paper} open={cite} onOpenChange={setCite} />
    </article>
  );
}
