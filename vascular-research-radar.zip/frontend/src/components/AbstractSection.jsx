import { ExternalLink } from "lucide-react";
import { fullPaperUrl } from "@/lib/format";

export function AbstractSection({ paper }) {
  const sections = paper.abstract_sections || [];
  const url = fullPaperUrl(paper);
  return (
    <section className="space-y-5" data-testid="abstract-section">
      {paper.conclusion && (
        <div className="rounded-2xl bg-[hsl(var(--highlight))] p-5 sm:p-7" data-testid="conclusion-highlight">
          <div className="eyebrow !text-[hsl(var(--highlight-ink))] mb-2">Authors' conclusion</div>
          <p className="reading !text-[hsl(var(--highlight-ink))] font-medium">{paper.conclusion}</p>
        </div>
      )}
      <div className="surface p-5 sm:p-8">
        <h2 className="font-read text-2xl font-semibold mb-4">Abstract</h2>
        {sections.length ? (
          <div className="space-y-5">
            {sections.map((s, i) => (
              <div key={i}>
                {s.label && <h3 className="eyebrow mb-1.5">{s.label}</h3>}
                <p className="reading">{s.text}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-[hsl(var(--ink-soft))]" data-testid="abstract-unavailable">
            Abstract not available.{" "}
            {url && <a href={url} target="_blank" rel="noopener noreferrer" className="font-semibold text-[hsl(var(--accent))] inline-flex items-center gap-1">Read it at the source <ExternalLink className="w-4 h-4" /></a>}
          </p>
        )}
        <p className="mt-6 pt-4 border-t text-sm text-[hsl(var(--ink-faint))]">
          Abstract text as published, retrieved from {paper.source === "PubMed" ? "PubMed" : "PubMed / Europe PMC"}. Not summarised or rewritten.
        </p>
      </div>
    </section>
  );
}
