import { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Toaster, toast } from "sonner";
import "@/App.css";
import { TopNav } from "@/components/TopNav";
import { HistoryProvider } from "@/lib/history";
import { fetchPapers, fetchStatus, runNow } from "@/lib/api";
import DashboardPage from "@/pages/DashboardPage";
import PaperPage from "@/pages/PaperPage";
import LibraryPage from "@/pages/LibraryPage";
import SavedPage from "@/pages/SavedPage";
import SettingsPage from "@/pages/SettingsPage";

function Footer() {
  return (
    <footer className="no-print border-t mt-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 text-sm text-[hsl(var(--ink-faint))] space-y-2">
        <p className="font-read text-base text-[hsl(var(--ink-soft))]">Vascular Research Radar</p>
        <p>Free sources: PubMed and Europe PMC · Curated high-impact journal list · <Link to="/settings" className="underline">Settings</Link></p>
        <p data-testid="medical-disclaimer">For research reading only. Not medical advice.</p>
      </div>
    </footer>
  );
}

function Shell() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [dark, setDark] = useState(() => localStorage.getItem("vrr-theme") ? localStorage.getItem("vrr-theme") === "dark" : window.matchMedia?.("(prefers-color-scheme: dark)").matches);
  const [running, setRunning] = useState(false);
  const papersQ = useQuery({ queryKey: ["papers"], queryFn: fetchPapers, refetchInterval: 60000 });
  const statusQ = useQuery({ queryKey: ["status"], queryFn: fetchStatus, refetchInterval: 60000 });
  const papers = papersQ.data || [];

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("vrr-theme", dark ? "dark" : "light");
  }, [dark]);

  const handleRunNow = async () => {
    setRunning(true);
    try {
      const res = await runNow();
      await Promise.all(["papers", "status", "logs"].map((k) => qc.invalidateQueries({ queryKey: [k] })));
      if (res.paper) {
        toast.success(res.message);
        navigate(`/paper/${res.paper.paper_id}`);
        window.scrollTo({ top: 0 });
      } else toast(res.message);
    } catch {
      toast.error("Couldn't reach the search right now. Please try again.");
    } finally {
      setRunning(false);
    }
  };

  const shared = { papers, loading: papersQ.isLoading };
  return (
    <div className="grain min-h-screen flex flex-col relative">
      <TopNav dark={dark} onToggleDark={() => setDark(!dark)} onRunNow={handleRunNow} running={running} />
      <main className="flex-1 relative z-[1]">
        <Routes>
          <Route path="/" element={<DashboardPage {...shared} status={statusQ.data} running={running} />} />
          <Route path="/today" element={<PaperPage {...shared} latest />} />
          <Route path="/paper/:id" element={<PaperPage {...shared} />} />
          <Route path="/library" element={<LibraryPage {...shared} />} />
          <Route path="/saved" element={<SavedPage {...shared} />} />
          <Route path="/settings" element={<SettingsPage onRunNow={handleRunNow} running={running} />} />
        </Routes>
      </main>
      <Footer />
      <Toaster position="bottom-center" theme={dark ? "dark" : "light"} richColors />
    </div>
  );
}

export default function App() {
  return (
    <HistoryProvider>
      <BrowserRouter>
        <Shell />
      </BrowserRouter>
    </HistoryProvider>
  );
}
