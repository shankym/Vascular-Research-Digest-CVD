import { useParams, Link } from "react-router-dom";
import PaperDetail from "@/components/PaperDetail";

export default function PaperPage({ papers, loading, latest = false }) {
  const { id } = useParams();
  const paper = latest ? papers[0] : papers.find((p) => p.paper_id === id);
  if (paper) return <PaperDetail paper={paper} />;
  return (
    <div className="max-w-xl mx-auto px-4 py-20 text-center" data-testid="paper-not-found">
      <p className="font-read text-xl">{loading ? "Loading…" : latest ? "No paper found yet today." : "This paper isn't in the library."}</p>
      {!loading && <Link to="/library" className="mt-4 inline-block font-semibold text-[hsl(var(--accent))]">Go to the library</Link>}
    </div>
  );
}
