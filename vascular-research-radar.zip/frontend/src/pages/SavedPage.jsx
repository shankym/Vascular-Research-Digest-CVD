import { Link } from "react-router-dom";
import { Bookmark, ArrowRight } from "lucide-react";
import { MetaLine } from "@/components/MetaLine";
import { SaveReadButtons } from "@/components/SaveReadButtons";
import { NotesBox } from "@/components/NotesBox";
import { useHistory } from "@/lib/history";
import { authorsLine } from "@/lib/format";

export default function SavedPage({ papers }) {
  const h = useHistory();
  const saved = papers
    .filter((p) => h.get(p.paper_id).saved)
    .sort((a, b) => (h.get(b.paper_id).saved_at || "").localeCompare(h.get(a.paper_id).saved_at || ""));
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-8 py-8 sm:py-12 space-y-6">
      <header>
        <h1 className="font-read text-4xl sm:text-5xl font-semibold tracking-tight">Saved &amp; notes</h1>
        <p className="mt-2 text-base md:text-lg text-[hsl(var(--ink-soft))]">Your reading list. Saved papers and notes stay on this device only.</p>
      </header>
      {saved.length ? saved.map((p, i) => (
        <article key={p.paper_id} className="surface p-5 sm:p-7 space-y-3 rise" style={{ animationDelay: `${i * 50}ms` }} data-testid={`saved-item-${p.paper_id}`}>
          <div className="flex items-start justify-between gap-3">
            <MetaLine paper={p} />
            <SaveReadButtons id={p.paper_id} />
          </div>
          <Link to={`/paper/${p.paper_id}`}><h2 className="font-read text-[1.3rem] sm:text-2xl font-semibold leading-snug hover:text-[hsl(var(--accent))] transition-colors">{p.title}</h2></Link>
          <p className="text-[0.95rem] text-[hsl(var(--ink-soft))]">{authorsLine(p, 5)}</p>
          <div className="pt-3 border-t"><NotesBox id={p.paper_id} compact /></div>
          <div className="flex items-center justify-between text-sm text-[hsl(var(--ink-faint))]">
            <span>Saved {h.get(p.paper_id).saved_at ? new Date(h.get(p.paper_id).saved_at).toLocaleDateString() : ""}</span>
            <Link to={`/paper/${p.paper_id}`} className="flex items-center gap-1.5 font-semibold text-[hsl(var(--accent))]">Open <ArrowRight className="w-4 h-4" /></Link>
          </div>
        </article>
      )) : (
        <div className="surface p-10 text-center" data-testid="saved-empty">
          <Bookmark className="w-8 h-8 mx-auto mb-3 text-[hsl(var(--ink-faint))]" />
          <p className="font-read text-xl">Nothing saved yet.</p>
          <p className="text-[hsl(var(--ink-soft))] mt-2">Tap the bookmark on any paper to keep it here.</p>
        </div>
      )}
    </div>
  );
}
