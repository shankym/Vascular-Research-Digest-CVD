import { Link } from "react-router-dom";
import { ArrowRight, BookOpen } from "lucide-react";
import { Countdown } from "@/components/Countdown";
import { MetaLine } from "@/components/MetaLine";
import { SaveReadButtons } from "@/components/SaveReadButtons";
import { PaperCard } from "@/components/PaperCard";
import { useHistory } from "@/lib/history";
import { authorsLine, abstractText } from "@/lib/format";

function Stat({ label, value, testId }) {
  return (
    <div className="surface px-5 py-4">
      <div className="eyebrow mb-1">{label}</div>
      <div className="font-read text-3xl font-semibold" data-testid={testId}>{value}</div>
    </div>
  );
}

function Hero({ paper }) {
  return (
    <section className="surface p-6 sm:p-10 rise relative overflow-hidden" data-testid="latest-paper-hero">
      <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-[hsl(var(--accent))]" aria-hidden />
      <div className="flex items-start justify-between gap-4 mb-4">
        <div className="min-w-0">
          <div className="eyebrow !text-[hsl(var(--accent))] mb-2">Latest find</div>
          <MetaLine paper={paper} testId="latest-paper-meta" />
        </div>
        <SaveReadButtons id={paper.paper_id} />
      </div>
      <h2 className="font-read text-[1.6rem] sm:text-4xl font-semibold leading-tight tracking-tight mb-3" data-testid="latest-paper-title">
        {paper.title}
      </h2>
      <p className="text-[0.98rem] text-[hsl(var(--ink-soft))] mb-6">{authorsLine(paper, 6)}</p>
      {paper.conclusion ? (
        <div className="rounded-xl bg-[hsl(var(--highlight))] p-5 mb-6">
          <div className="eyebrow !text-[hsl(var(--highlight-ink))] mb-1.5">Authors' conclusion</div>
          <p className="reading !text-[hsl(var(--highlight-ink))]">{paper.conclusion}</p>
        </div>
      ) : (
        <p className="reading line-clamp-4 mb-6">{abstractText(paper) || "Abstract not available."}</p>
      )}
      <Link
        to={`/paper/${paper.paper_id}`}
        data-testid="latest-paper-open-button"
        className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-[hsl(var(--ink))] text-[hsl(var(--surface))] font-semibold hover:gap-3 transition-[gap]"
      >
        Read the full abstract <ArrowRight className="w-4 h-4" />
      </Link>
    </section>
  );
}

export default function DashboardPage({ papers, status, running, loading }) {
  const { all } = useHistory();
  const stats = status?.stats;
  const latest = papers[0];
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 sm:py-12 space-y-8 sm:space-y-10">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-read text-4xl sm:text-5xl lg:text-6xl font-semibold tracking-tight leading-[1.05]">
            One good paper,<br className="hidden sm:block" /> every hour.
          </h1>
          <p className="mt-3 text-base md:text-lg text-[hsl(var(--ink-soft))] max-w-xl">
            New arterial stiffness and cardiovascular research from a curated list of high-impact journals, with the real abstract.
          </p>
        </div>
        {stats && <Countdown nextRunTime={stats.nextRunTime} lastRunTime={stats.lastRunTime} running={running} />}
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <Stat label="In the library" value={stats?.totalPapers ?? "–"} testId="stat-total-papers" />
        <Stat label="Saved on this device" value={Object.values(all).filter((h) => h.saved).length} testId="stat-saved" />
        <Stat label="Real figures" value={stats?.totalFigures ?? "–"} testId="stat-figures" />
        <Stat label="New papers" value="1 / hour" testId="stat-cadence" />
      </div>

      {latest ? <Hero paper={latest} /> : (
        <div className="surface p-10 text-center" data-testid="dashboard-empty">
          <BookOpen className="w-8 h-8 mx-auto mb-3 text-[hsl(var(--ink-faint))]" />
          <h3 className="font-read text-xl font-semibold">{loading ? "Loading the library…" : "The first papers are on their way"}</h3>
          <p className="text-[hsl(var(--ink-soft))] mt-2">Searching PubMed and Europe PMC. Tap “Run now” to fetch one straight away.</p>
        </div>
      )}

      {papers.length > 1 && (
        <section>
          <div className="flex items-end justify-between mb-4">
            <h2 className="font-read text-2xl font-semibold">Recently added</h2>
            <Link to="/library" className="text-[0.95rem] font-semibold text-[hsl(var(--accent))]" data-testid="view-library-link">See all</Link>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            {papers.slice(1, 5).map((p, i) => <PaperCard key={p.paper_id} paper={p} index={i} />)}
          </div>
        </section>
      )}
    </div>
  );
}
