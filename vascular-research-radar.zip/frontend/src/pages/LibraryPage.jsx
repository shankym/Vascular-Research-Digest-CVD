import { useMemo, useState } from "react";
import { BookOpen } from "lucide-react";
import { LibraryFilters } from "@/components/LibraryFilters";
import { PaperCard } from "@/components/PaperCard";
import { useHistory } from "@/lib/history";
import { abstractText, pubYear } from "@/lib/format";

const INITIAL = { search: "", category: "All", journal: "All", type: "All", year: "All", sort: "added", savedOnly: false, readOnly: false };
const uniq = (arr) => [...new Set(arr.filter(Boolean))].sort();

function sortPapers(list, sort) {
  const cmp = {
    published: (a, b) => (b.publication_date || "").localeCompare(a.publication_date || ""),
    oldest: (a, b) => (a.publication_date || "9").localeCompare(b.publication_date || "9"),
    citations: (a, b) => (b.citation_count ?? -1) - (a.citation_count ?? -1),
    title: (a, b) => a.title.localeCompare(b.title),
  }[sort];
  return cmp ? [...list].sort(cmp) : list;
}

export default function LibraryPage({ papers }) {
  const [f, setF] = useState(INITIAL);
  const h = useHistory();
  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));
  const options = useMemo(() => ({
    categories: uniq(papers.map((p) => p.category)),
    journals: uniq(papers.map((p) => p.journal)),
    types: uniq(papers.map((p) => p.article_type)),
    years: uniq(papers.map((p) => pubYear(p.publication_date))).reverse(),
  }), [papers]);

  const list = useMemo(() => {
    const q = f.search.trim().toLowerCase();
    const out = papers.filter((p) =>
      (!q || [p.title, p.DOI, abstractText(p), ...(p.authors || [])].join(" ").toLowerCase().includes(q)) &&
      (f.category === "All" || p.category === f.category) &&
      (f.journal === "All" || p.journal === f.journal) &&
      (f.type === "All" || p.article_type === f.type) &&
      (f.year === "All" || pubYear(p.publication_date) === f.year) &&
      (!f.savedOnly || h.get(p.paper_id).saved) &&
      (!f.readOnly || h.get(p.paper_id).read));
    return sortPapers(out, f.sort);
  }, [papers, f, h]);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-8 py-8 sm:py-12 space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
        <div>
          <h1 className="font-read text-4xl sm:text-5xl font-semibold tracking-tight">Library</h1>
          <p className="mt-2 text-base md:text-lg text-[hsl(var(--ink-soft))]">Every paper the radar has found.</p>
        </div>
        <p className="text-[hsl(var(--ink-soft))]" data-testid="library-count">Showing <b>{list.length}</b> of <b>{papers.length}</b></p>
      </header>
      <LibraryFilters f={f} set={set} reset={() => setF(INITIAL)} options={options} />
      {list.length ? (
        <div className="grid md:grid-cols-2 gap-4">{list.map((p, i) => <PaperCard key={p.paper_id} paper={p} index={i} />)}</div>
      ) : (
        <div className="surface p-10 text-center" data-testid="library-empty">
          <BookOpen className="w-8 h-8 mx-auto mb-3 text-[hsl(var(--ink-faint))]" />
          <p className="font-read text-xl">No papers match these filters.</p>
          <button onClick={() => setF(INITIAL)} className="mt-4 font-semibold text-[hsl(var(--accent))]" data-testid="library-empty-reset">Reset filters</button>
        </div>
      )}
    </div>
  );
}
