import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2, Download, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { fetchSettings, saveSettings, fetchJournals, fetchLogs, fetchExport } from "@/lib/api";
import { useHistory } from "@/lib/history";

const TOPICS = ["Arterial Stiffness", "Endothelial Function", "Cardiovascular Disease", "Related Research"];

function Card({ title, desc, children, testId }) {
  return (
    <section className="surface p-5 sm:p-7" data-testid={testId}>
      <h2 className="font-read text-2xl font-semibold">{title}</h2>
      {desc && <p className="mt-1 mb-5 text-[hsl(var(--ink-soft))]">{desc}</p>}
      {children}
    </section>
  );
}

function Logs() {
  const { data: logs = [] } = useQuery({ queryKey: ["logs"], queryFn: fetchLogs, refetchInterval: 60000 });
  const [filter, setFilter] = useState("all");
  const shown = logs.filter((l) => filter === "all" || l.execution_status === filter);
  const dot = { success: "bg-[hsl(var(--good))]", warning: "bg-amber-500", error: "bg-red-500" };
  return (
    <Card title="Search history" desc="What the radar did on each run." testId="settings-logs">
      <div className="flex gap-1.5 mb-4 flex-wrap">
        {["all", "success", "warning", "error"].map((f) => (
          <button key={f} onClick={() => setFilter(f)} data-testid={`log-filter-${f}`}
            className={`px-3.5 py-1.5 rounded-full text-sm capitalize border ${filter === f ? "bg-[hsl(var(--ink))] text-[hsl(var(--surface))]" : ""}`}>{f}</button>
        ))}
      </div>
      <ul className="space-y-2 max-h-96 overflow-y-auto">
        {shown.map((l) => (
          <li key={l.id} className="p-3 rounded-xl bg-[hsl(var(--paper))] border text-[0.95rem]" data-testid="log-item">
            <div className="flex items-start gap-2">
              <span className={`mt-2 w-2 h-2 rounded-full shrink-0 ${dot[l.execution_status] || "bg-gray-400"}`} />
              <div className="min-w-0">
                <div className="font-medium break-words">{l.selected_paper}{l.journal ? ` · ${l.journal}` : ""}</div>
                <div className="text-sm text-[hsl(var(--ink-faint))]">{new Date(l.execution_time).toLocaleString()} · {l.details}</div>
              </div>
            </div>
          </li>
        ))}
        {!shown.length && <li className="text-[hsl(var(--ink-faint))]">No entries yet.</li>}
      </ul>
    </Card>
  );
}

export default function SettingsPage({ onRunNow, running }) {
  const qc = useQueryClient();
  const { all } = useHistory();
  const { data: settings } = useQuery({ queryKey: ["settings"], queryFn: fetchSettings });
  const { data: journals = [] } = useQuery({ queryKey: ["journals"], queryFn: fetchJournals });
  const [form, setForm] = useState(null);
  const [newJournal, setNewJournal] = useState("");
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (settings) setForm((f) => f || settings);
  }, [settings]);
  if (!form) return null;

  const save = async (patch) => {
    if (saving) return;
    const prev = form;
    const next = { ...form, ...patch };
    setForm(next);
    setSaving(true);
    try {
      const res = await saveSettings({ journal_whitelist: next.journal_whitelist, research_categories: next.research_categories, scheduling_enabled: next.scheduling_enabled });
      setForm(res);
      qc.setQueryData(["settings"], res);
      qc.invalidateQueries({ queryKey: ["status"] });
      toast.success("Settings saved");
    } catch {
      setForm(prev);
      toast.error("Couldn't save settings. Please try again.");
    } finally {
      setSaving(false);
    }
  };
  const toggleTopic = (t) => {
    const cur = form.research_categories;
    const next = cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t];
    if (next.length) save({ research_categories: next });
  };
  const addJournal = () => {
    const j = newJournal.trim();
    if (!j || form.journal_whitelist.includes(j)) return;
    setNewJournal("");
    save({ journal_whitelist: [...form.journal_whitelist, j] });
  };
  const doExport = async () => {
    const data = { ...(await fetchExport()), this_device: all };
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    Object.assign(document.createElement("a"), { href: url, download: "vascular_research_radar_backup.json" }).click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-8 py-8 sm:py-12 space-y-6">
      <header>
        <h1 className="font-read text-4xl sm:text-5xl font-semibold tracking-tight">Settings</h1>
        <p className="mt-2 text-base md:text-lg text-[hsl(var(--ink-soft))]">These settings are shared by everyone who uses this app.</p>
      </header>

      <Card title="Hourly search" desc="Once an hour the radar searches PubMed and Europe PMC and adds one new paper." testId="settings-automation">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <label className="flex items-center gap-3 text-base">
            <Switch checked={form.scheduling_enabled} onCheckedChange={(v) => save({ scheduling_enabled: v })} data-testid="scheduling-switch" />
            {form.scheduling_enabled ? "On, every hour" : "Paused"}
          </label>
          <button onClick={onRunNow} disabled={running} data-testid="settings-run-now-button"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-full bg-[hsl(var(--accent))] text-white dark:text-[hsl(var(--paper))] font-semibold disabled:opacity-60">
            <RefreshCw className={`w-4 h-4 ${running ? "animate-spin" : ""}`} /> {running ? "Searching…" : "Find a paper now"}
          </button>
        </div>
      </Card>

      <Card title="Topics" desc="The radar picks one of these at random on each search." testId="settings-topics">
        <div className="flex flex-wrap gap-2">
          {TOPICS.map((t) => {
            const on = form.research_categories.includes(t);
            return (
              <button key={t} onClick={() => toggleTopic(t)} aria-pressed={on} data-testid={`topic-toggle-${t.toLowerCase().replace(/\s+/g, "-")}`}
                className={`px-4 py-2.5 rounded-full border text-[0.95rem] font-medium transition-colors ${on ? "bg-[hsl(var(--ink))] text-[hsl(var(--surface))]" : "hover:bg-[hsl(var(--secondary))]"}`}>{t}</button>
            );
          })}
        </div>
      </Card>

      <Card title="Extra journals" desc="Papers from these journals are accepted too, on top of the curated list below. Use the journal's full name." testId="settings-allow-list">
        <div className="flex gap-2 mb-4">
          <input value={newJournal} onChange={(e) => setNewJournal(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addJournal()}
            placeholder="e.g. Hypertension Research" data-testid="allow-list-input"
            className="flex-1 min-w-0 px-4 py-3 rounded-xl bg-[hsl(var(--paper))] border text-base focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent)/0.35)]" />
          <button onClick={addJournal} data-testid="allow-list-add-button" className="flex items-center gap-1.5 px-4 rounded-xl bg-[hsl(var(--ink))] text-[hsl(var(--surface))] font-semibold"><Plus className="w-4 h-4" /> Add</button>
        </div>
        <ul className="flex flex-wrap gap-2" data-testid="allow-list">
          {form.journal_whitelist.map((j) => (
            <li key={j} className="flex items-center gap-2 pl-4 pr-2 py-1.5 rounded-full border bg-[hsl(var(--paper))]">
              {j}
              <button onClick={() => save({ journal_whitelist: form.journal_whitelist.filter((x) => x !== j) })} aria-label={`Remove ${j}`} data-testid={`allow-list-remove-${j}`} className="p-1 rounded-full hover:text-red-600"><Trash2 className="w-4 h-4" /></button>
            </li>
          ))}
          {!form.journal_whitelist.length && <li className="text-[hsl(var(--ink-faint))]">No extra journals added.</li>}
        </ul>
      </Card>

      <Card title="Curated high-impact journal list" desc="Built into the app. Only papers from these journals (and your extras) are added." testId="settings-curated-journals">
        <ul className="grid sm:grid-cols-2 gap-x-6">
          {journals.map((j) => (
            <li key={j.name} className="py-2.5 border-b">
              <div className="font-medium">{j.name}</div>
              <div className="text-sm text-[hsl(var(--ink-faint))]">{j.category}</div>
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Backup" desc="Download every paper, the search history and settings, plus the saved papers and notes on this device." testId="settings-export">
        <button onClick={doExport} data-testid="export-button" className="inline-flex items-center gap-2 px-5 py-3 rounded-full border font-semibold hover:bg-[hsl(var(--secondary))]">
          <Download className="w-4 h-4" /> Download backup (JSON)
        </button>
      </Card>

      <Logs />
    </div>
  );
}
